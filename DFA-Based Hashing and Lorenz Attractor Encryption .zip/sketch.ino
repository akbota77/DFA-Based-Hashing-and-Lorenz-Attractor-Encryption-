#include <SPI.h>
#include <SD.h>

#define BUTTON_PIN 2         // Кнопка регистрации/аутентификации
#define RED_LED_PIN 1        // Красный светодиод
#define GREEN_LED_PIN 4      // Зеленый светодиод
#define SD_CS_PIN 10         // SD-карта
#define SENSOR_PIN A0        // Датчик (LM35 или фоторезистор)

File dataFile;
byte encryptionKey = 0x5A;  // Ключ для XOR-шифрования

void setup() {
    Serial.begin(115200);
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    pinMode(RED_LED_PIN, OUTPUT);
    pinMode(GREEN_LED_PIN, OUTPUT);
    pinMode(SENSOR_PIN, INPUT);
    pinMode(SD_CS_PIN, OUTPUT);

    if (!SD.begin(SD_CS_PIN)) {
        Serial.println("SD card error!");
        while (1);
    }
    Serial.println("SD card initialized");
}

// Генерация ID через DFA
int generateDFA_ID(int sensorValue) {
    return (sensorValue * 31) % 10000;
}

// Аттрактор Лоренца (генерация криптографического ключа)
float lorenzEncrypt(float x) {
    float sigma = 10.0, beta = 2.666, rho = 28.0;
    return sigma * (rho - x) - beta * x;
}

// XOR-шифрование
String xorEncrypt(String data) {
    String encrypted = "";
    for (int i = 0; i < data.length(); i++) {
        encrypted += char(data[i] ^ encryptionKey);
    }
    return encrypted;
}

// Сохранение данных на SD-карту
void saveToSD(String data) {
    // String fn = "auth.txt";
    // char f_n[fn.length()+1];
    // fn.toCharArray(f_n, fn.length());
    dataFile = SD.open("auth.txt", FILE_WRITE);
    if (dataFile) {
        dataFile.println(data);
        dataFile.close();
        Serial.println("Data saved");
    } else {
        Serial.println("Error writing to SD card");
    }
}

// Чтение данных с датчика
int readSensor() {
    return analogRead(SENSOR_PIN);
}

void loop() {
    if (digitalRead(BUTTON_PIN) == LOW) {
        digitalWrite(RED_LED_PIN, LOW);
        digitalWrite(GREEN_LED_PIN, LOW);

        int sensorValue = readSensor();
        int sensorID = generateDFA_ID(sensorValue);
        float key = lorenzEncrypt(sensorValue);

        Serial.print("Sensor ID: ");
        Serial.println(sensorID);
        Serial.print("Key: ");
        Serial.println(key);

        String encryptedData = xorEncrypt(String(sensorID));
        Serial.print("Encrypted data ");
        Serial.println(encryptedData);

        saveToSD(encryptedData);

        digitalWrite(GREEN_LED_PIN, HIGH);
        delay(1000);
        digitalWrite(GREEN_LED_PIN, LOW);
    }
}
